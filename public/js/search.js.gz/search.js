// Blog Search - Beautiful UI Version
console.log('[Search] Script loaded');

(function() {
    'use strict';
    
    if (window.searchInitialized) {
        console.log('[Search] Already initialized');
        return;
    }
    window.searchInitialized = true;
    
    let searchIndex = null;
    let fuse = null;
    
    function createSearchBox() {
        if (document.getElementById('blog-search-container')) {
            return;
        }
        
        const searchHTML = `
            <div id="blog-search-container" style="padding: 16px; margin-bottom: 20px;">
                <div style="max-width: 600px; margin: 0 auto;">
                    <div style="position: relative;">
                        <input type="text" 
                               id="blog-search-input" 
                               placeholder="🔍 Search posts..." 
                               style="width: 100%; padding: 12px 40px 12px 16px; font-size: 15px; border: 1px solid #ddd; border-radius: 6px; outline: none; box-sizing: border-box; background: #fafafa; transition: all 0.2s ease; font-family: inherit;">
                        <span style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); color: #999; pointer-events: none; font-size: 12px;">⌘K</span>
                    </div>
                </div>
            </div>
        `;
        
        const main = document.querySelector('main');
        if (main) {
            main.insertAdjacentHTML('afterbegin', searchHTML);
            attachSearchListener();
            attachKeyboardShortcut();
        }
    }
    
    function attachSearchListener() {
        const input = document.getElementById('blog-search-input');
        if (input) {
            input.addEventListener('input', debounce(handleSearch, 300));
            input.addEventListener('focus', function() {
                this.style.borderColor = '#f6821f';
                this.style.background = '#fff';
                this.style.boxShadow = '0 0 0 3px rgba(246, 130, 31, 0.1)';
            });
            input.addEventListener('blur', function() {
                this.style.borderColor = '#ddd';
                this.style.background = '#fafafa';
                this.style.boxShadow = 'none';
            });
        }
    }
    
    function attachKeyboardShortcut() {
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                document.getElementById('blog-search-input')?.focus();
            }
        });
    }
    
    function debounce(func, ms) {
        let timeout;
        return function(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), ms);
        };
    }
    
    function handleSearch(e) {
        const query = e.target.value.trim();
        
        if (query.length < 2) {
            hideResults();
            return;
        }
        
        if (!searchIndex) {
            loadIndex(() => search(query));
        } else if (fuse) {
            search(query);
        }
    }
    
    function loadIndex(callback) {
        fetch('/search-index.min.json')
            .then(r => r.json())
            .then(data => {
                searchIndex = data;
                loadFuse(callback);
            })
            .catch(e => console.error('[Search] Failed to load index:', e));
    }
    
    function loadFuse(callback) {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/fuse.js@7.0.0';
        script.onload = () => {
            fuse = new window.Fuse(searchIndex, {
                keys: ['title', 'description', 'content'],
                threshold: 0.4,
                includeMatches: true,
                ignoreLocation: true,
                minMatchCharLength: 2
            });
            if (callback) callback();
        };
        document.head.appendChild(script);
    }
    
    function search(query) {
        if (!fuse) return;
        
        const results = fuse.search(query);
        displayResults(results, query);
        
        // Track search analytics (privacy-friendly)
        trackSearch(query, results.length);
    }
    
    function displayResults(results, query) {
        hideResults();
        
        let html = `<div class="search-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 99999; display: flex; flex-direction: column; align-items: center; justify-content: flex-start; padding: 20px; overflow-y: auto; animation: fadeIn 0.2s ease;" onclick="if(event.target===this) this.remove()">
            <div style="background: white; border-radius: 12px; max-width: 650px; width: 100%; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 60px rgba(0,0,0,0.3); animation: slideUp 0.3s ease; margin-top: 20px;">
                <div style="padding: 20px; border-bottom: 1px solid #e5e7eb; background: #f9fafb; position: sticky; top: 0; z-index: 10;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px;">
                        <div style="flex: 1;">
                            <div style="font-size: 13px; color: #667eea; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">Search Results</div>
                            <div style="font-size: 16px; font-weight: 700; color: #111; word-break: break-word;">` + results.length + ` result` + (results.length !== 1 ? 's' : '') + `</div>
                        </div>
                        <button onclick="this.closest('.search-overlay').remove()" style="background: #f0f0f0; border: none; font-size: 20px; cursor: pointer; color: #333; padding: 0; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 6px; transition: all 0.2s; flex-shrink: 0;" onmouseover="this.style.background='#e0e0e0'" onmouseout="this.style.background='#f0f0f0'">×</button>
                    </div>
                </div>
                <div style="overflow-y: auto; max-height: calc(75vh - 120px);">`;
        
        if (results.length === 0) {
            html += `<div style="padding: 60px 40px; text-align: center;">
                <div style="font-size: 48px; margin-bottom: 16px;">🔍</div>
                <div style="font-size: 18px; font-weight: 600; color: #111; margin-bottom: 8px;">No results found</div>
                <div style="color: #666; font-size: 14px;">Try searching for different keywords</div>
            </div>`;
        } else {
            results.slice(0, 10).forEach((r, idx) => {
                const item = r.item;
                const highlightedTitle = highlightSearchTerms(item.title, query);
                const highlightedDesc = highlightSearchTerms((item.description || '').substring(0, 150), query);
                const safeUrl = /^https?:\/\//.test(item.url) ? item.url : '#';

                html += `<a href="` + safeUrl + `" style="display: block; padding: 16px; border-bottom: 1px solid #f0f0f0; text-decoration: none; color: inherit; transition: all 0.15s;" onmouseover="this.style.background='#f9fafb'" onmouseout="this.style.background='white'">
                    <div style="display: flex; align-items: flex-start; gap: 10px;">
                        <div style="flex-shrink: 0; width: 28px; height: 28px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 6px; display: flex; align-items: center; justify-content: center; color: white; font-size: 12px; font-weight: 600;">` + (idx + 1) + `</div>
                        <div style="flex: 1; min-width: 0;">
                            <div style="font-size: 14px; font-weight: 600; color: #111; margin-bottom: 4px; line-height: 1.3;">` + highlightedTitle + `</div>
                            <div style="font-size: 12px; color: #666; margin-bottom: 6px; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">` + highlightedDesc + `</div>
                            <div style="font-size: 11px; color: #999; word-break: break-all;">` + item.url.replace('https://jameskilby.co.uk', '') + `</div>
                        </div>
                    </div>
                </a>`;
            });
        }
        
        html += `</div>
            </div>
            <style>
                @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
                @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
            </style>
        </div>`;
        
        const div = document.createElement('div');
        div.innerHTML = html;
        document.body.appendChild(div.firstChild);
    }
    
    function hideResults() {
        const overlay = document.querySelector('.search-overlay');
        if (overlay) overlay.remove();
    }
    
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // Highlight search terms in text
    function highlightSearchTerms(text, query) {
        if (!query || !text) return escapeHtml(text);
        
        const escapedText = escapeHtml(text);
        const terms = query.toLowerCase().split(/\s+/).filter(t => t.length > 1);
        
        let highlighted = escapedText;
        terms.forEach(term => {
            const regex = new RegExp(`(${term})`, 'gi');
            highlighted = highlighted.replace(regex, '<mark style="background-color: #fef3c7; padding: 1px 2px; border-radius: 2px; font-weight: 500;">$1</mark>');
        });
        
        return highlighted;
    }
    
    // Privacy-friendly search analytics
    function trackSearch(query, resultCount) {
        // Send to Plausible as custom event (respects DNT and privacy)
        if (window.plausible) {
            window.plausible('Search', {
                props: {
                    query_length: query.length,
                    result_count: resultCount,
                    has_results: resultCount > 0 ? 'yes' : 'no'
                }
            });
        }
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', createSearchBox);
    } else {
        createSearchBox();
    }
})();
