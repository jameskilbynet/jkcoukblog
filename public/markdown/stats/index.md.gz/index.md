---
title: "Site Statistics"
description: "Public statistics and metrics for James Kilby's technical blog including performance scores, traffic data, and build information."
author: James Kilby
url: https://jameskilby.co.uk/stats/
---

[← Back to Home](https://jameskilby.co.uk/)

# 📊 Site Statistics

Public metrics, performance scores, and analytics for jameskilby.co.uk

📄

172

Total Pages

📝

69

Blog Posts

🖼️

3034

Images

💾

169.0

Total Size (MB)

🚀

1076

Deployments

📅

120

Updates This Month

## 🚀 Lighthouse Performance Scores

Latest scores from 2026-04-01 deployment

95 

Performance

95 

Accessibility

100 

Best Practices

100 

SEO

**📈 Performance Tracking:** Scores are automatically measured on every deployment and stored in the changelog history.

**🎯 Target:** Maintaining 90+ scores across all categories for optimal user experience.

## 🔧 Build Metrics

Metric | Value | Notes  
---|---|---  
Total HTML Pages | 172 | All generated pages including posts, archives, and pages  
Blog Posts | 69 | Articles in dated directories (YYYY/MM/slug)  
Total Images | 3034 | Optimized images (PNG, JPG, WebP, SVG)  
Total Site Size | 169.0 MB | All files in public directory  
Average Page Size | 0.98 KB | Total size / number of pages  
Images per Post | 44.0 | Average images per blog post  
Last Deployment | 2026-04-01 21:44:58 | Most recent static site generation  
Total Deployments | 1076 | Git commits to main branch  
  
## 📊 Traffic Analytics (Plausible)

Privacy-friendly analytics with no cookies or tracking. Data is aggregated and anonymous.

**🔒 Privacy First:** This site uses [Plausible Analytics](https://plausible.io) \- a privacy-friendly alternative to Google Analytics.

**✅ No cookies, no tracking, no personal data collection**

**📊 Transparent:** All data is publicly shared below with full transparency

## ℹ️ About This Page

This statistics page is automatically generated on every deployment and includes:

  * **Lighthouse Scores:** Performance metrics from Google's Lighthouse CI
  * **Build Metrics:** Statistics about the static site generation process
  * **Git Statistics:** Deployment frequency and commit history
  * **Traffic Data:** Visitor analytics from Plausible (privacy-friendly)

**🔄 Auto-Updated:** This page regenerates with every site deployment

**🌐 Public:** All metrics are openly shared for transparency

**💻 Open Source:** Check the [GitHub repository](https://github.com/jameskilbynet/jkcoukblog) to see how this works

Page generated: 2026-04-01 22:09:48 UTC  
Stats powered by Plausible Analytics, Google Lighthouse, and Git